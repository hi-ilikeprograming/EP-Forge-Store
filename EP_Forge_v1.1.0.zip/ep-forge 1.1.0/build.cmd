@echo off
set "ROOT=%~dp0"
set "CSC=C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if not exist "%CSC%" (
  set "CSC=C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe"
)

if not exist "%CSC%" (
  echo Nie znaleziono kompilatora C# w .NET Framework.
  exit /b 1
)

"%CSC%" /nologo /target:winexe /out:"%ROOT%bin\EPForge.exe" /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll "%ROOT%src\Program.cs"

if errorlevel 1 exit /b 1
echo Zbudowano: %ROOT%bin\EPForge.exe
