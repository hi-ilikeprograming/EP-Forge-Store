using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace EPForge
{
    public static class Program
    {
        public const string AppVersion = "1.1.0";

        [STAThread]
        public static void Main(string[] args)
        {
            if (args.Length == 1 && args[0] == "--check")
            {
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    [Serializable]
    public class SceneProject
    {
        public string ProjectName { get; set; }
        public List<SceneObject> Objects { get; set; }

        public SceneProject()
        {
            ProjectName = "Nowy projekt EP 3D";
            Objects = new List<SceneObject>();
        }
    }

    [Serializable]
    public class SceneObject
    {
        public string Name { get; set; }
        public string Kind { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Z { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public int Depth { get; set; }
        public int ColorArgb { get; set; }
        public int SpeedX { get; set; }
        public int SpeedY { get; set; }
        public int SpeedZ { get; set; }
        public bool Solid { get; set; }

        [Browsable(false)]
        public Rectangle ScreenBounds
        {
            get { return new Rectangle(X, Y, Width, Height); }
        }

        public SceneObject()
        {
            Name = "Object";
            Kind = "Actor";
            X = 80;
            Y = 80;
            Z = 0;
            Width = 64;
            Height = 64;
            Depth = 64;
            ColorArgb = Color.DeepSkyBlue.ToArgb();
            SpeedX = 0;
            SpeedY = 0;
            SpeedZ = 0;
            Solid = true;
        }

        public override string ToString()
        {
            return Name + "  [" + Kind + "]";
        }
    }

    public class UpdateInfo
    {
        public Version Version;
        public string InstallerPath;
        public string Notes;
    }

    public static class UpdateChecker
    {
        public static UpdateInfo Check()
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            string manifestPath = Path.Combine(appDir, "latest.epupdate");

            if (!File.Exists(manifestPath))
            {
                return null;
            }

            Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (string rawLine in File.ReadAllLines(manifestPath))
            {
                string line = rawLine.Trim();
                if (line.Length == 0 || line.StartsWith("#"))
                {
                    continue;
                }

                int separator = line.IndexOf('=');
                if (separator <= 0)
                {
                    continue;
                }

                values[line.Substring(0, separator).Trim()] = line.Substring(separator + 1).Trim();
            }

            if (!values.ContainsKey("Version") || !values.ContainsKey("Installer"))
            {
                return null;
            }

            Version available = new Version(values["Version"]);
            Version current = new Version(Program.AppVersion);
            if (available <= current)
            {
                return null;
            }

            string installer = values["Installer"];
            if (!Path.IsPathRooted(installer))
            {
                installer = Path.Combine(appDir, installer);
            }

            UpdateInfo info = new UpdateInfo();
            info.Version = available;
            info.InstallerPath = installer;
            info.Notes = values.ContainsKey("Notes") ? values["Notes"] : "Nowa wersja EP Forge jest gotowa.";
            return info;
        }
    }

    public class SceneViewport : Control
    {
        private SceneProject project;
        private SceneObject selected;
        private bool dragging;
        private Point dragOffset;
        private readonly Timer playTimer;

        public event EventHandler SelectionChanged;
        public event EventHandler SceneChanged;

        public bool PlayMode { get; private set; }

        public SceneViewport()
        {
            DoubleBuffered = true;
            BackColor = Color.FromArgb(26, 30, 38);
            Dock = DockStyle.Fill;
            TabStop = true;

            playTimer = new Timer();
            playTimer.Interval = 16;
            playTimer.Tick += OnPlayTick;
        }

        public SceneProject Project
        {
            get { return project; }
            set
            {
                project = value;
                Selected = null;
                Invalidate();
            }
        }

        public SceneObject Selected
        {
            get { return selected; }
            set
            {
                selected = value;
                Invalidate();
                if (SelectionChanged != null)
                {
                    SelectionChanged(this, EventArgs.Empty);
                }
            }
        }

        public void StartPlay()
        {
            PlayMode = true;
            playTimer.Start();
            Invalidate();
        }

        public void StopPlay()
        {
            PlayMode = false;
            playTimer.Stop();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            DrawFloor(e.Graphics);
            DrawScene(e.Graphics);
            DrawOverlay(e.Graphics);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Focus();

            SceneObject hit = HitTest(e.Location);
            Selected = hit;

            if (hit != null && !PlayMode)
            {
                Point projected = ProjectPoint(hit.X, hit.Y, hit.Z);
                dragging = true;
                dragOffset = new Point(e.X - projected.X, e.Y - projected.Y);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (dragging && selected != null && !PlayMode)
            {
                Point world = UnprojectPoint(new Point(e.X - dragOffset.X, e.Y - dragOffset.Y), selected.Z);
                selected.X = world.X;
                selected.Y = world.Y;
                Invalidate();
                RaiseSceneChanged();
            }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            dragging = false;
        }

        private SceneObject HitTest(Point point)
        {
            if (project == null)
            {
                return null;
            }

            List<SceneObject> ordered = new List<SceneObject>(project.Objects);
            ordered.Sort(delegate(SceneObject a, SceneObject b)
            {
                return (a.X + a.Y + a.Z).CompareTo(b.X + b.Y + b.Z);
            });

            for (int i = ordered.Count - 1; i >= 0; i--)
            {
                Rectangle bounds = GetProjectedBounds(ordered[i]);
                if (bounds.Contains(point))
                {
                    return ordered[i];
                }
            }

            return null;
        }

        private Point ProjectPoint(int x, int y, int z)
        {
            int centerX = Width / 2;
            int baseY = Height / 2 + 130;
            int screenX = centerX + (x - y);
            int screenY = baseY + ((x + y) / 2) - z;
            return new Point(screenX, screenY);
        }

        private Point UnprojectPoint(Point screen, int z)
        {
            int centerX = Width / 2;
            int baseY = Height / 2 + 130;
            int a = screen.X - centerX;
            int b = (screen.Y - baseY + z) * 2;
            return new Point((a + b) / 2, (b - a) / 2);
        }

        private Rectangle GetProjectedBounds(SceneObject sceneObject)
        {
            Point p = ProjectPoint(sceneObject.X, sceneObject.Y, sceneObject.Z);
            return new Rectangle(p.X - sceneObject.Width / 2, p.Y - sceneObject.Height - sceneObject.Depth / 2, sceneObject.Width, sceneObject.Height + sceneObject.Depth);
        }

        private void DrawFloor(Graphics graphics)
        {
            using (Pen minor = new Pen(Color.FromArgb(45, 52, 64)))
            using (Pen major = new Pen(Color.FromArgb(64, 76, 92)))
            {
                for (int i = -640; i <= 640; i += 64)
                {
                    Point a = ProjectPoint(i, -640, 0);
                    Point b = ProjectPoint(i, 640, 0);
                    graphics.DrawLine(i % 256 == 0 ? major : minor, a, b);

                    Point c = ProjectPoint(-640, i, 0);
                    Point d = ProjectPoint(640, i, 0);
                    graphics.DrawLine(i % 256 == 0 ? major : minor, c, d);
                }
            }
        }

        private void DrawScene(Graphics graphics)
        {
            if (project == null)
            {
                return;
            }

            List<SceneObject> ordered = new List<SceneObject>(project.Objects);
            ordered.Sort(delegate(SceneObject a, SceneObject b)
            {
                return (a.X + a.Y + a.Z).CompareTo(b.X + b.Y + b.Z);
            });

            foreach (SceneObject sceneObject in ordered)
            {
                DrawObject(graphics, sceneObject);
            }
        }

        private void DrawObject(Graphics graphics, SceneObject sceneObject)
        {
            Color fill = Color.FromArgb(sceneObject.ColorArgb);
            Point p = ProjectPoint(sceneObject.X, sceneObject.Y, sceneObject.Z);
            int w = sceneObject.Width;
            int h = sceneObject.Height;
            int d = sceneObject.Depth;

            if (sceneObject.Kind == "Light")
            {
                Rectangle glow = new Rectangle(p.X - w / 2, p.Y - h - d / 2, w, h);
                using (Brush glowBrush = new SolidBrush(Color.FromArgb(120, fill)))
                using (Pen outline = new Pen(sceneObject == selected ? Color.White : Color.FromArgb(15, 18, 24), sceneObject == selected ? 3 : 1))
                {
                    graphics.FillEllipse(glowBrush, glow);
                    graphics.DrawEllipse(outline, glow);
                }
            }
            else
            {
                Point[] top = new Point[]
                {
                    new Point(p.X, p.Y - h - d),
                    new Point(p.X + w / 2, p.Y - h - d / 2),
                    new Point(p.X, p.Y - h),
                    new Point(p.X - w / 2, p.Y - h - d / 2)
                };

                Point[] left = new Point[]
                {
                    top[3],
                    top[2],
                    new Point(p.X, p.Y),
                    new Point(p.X - w / 2, p.Y - d / 2)
                };

                Point[] right = new Point[]
                {
                    top[1],
                    new Point(p.X + w / 2, p.Y - d / 2),
                    new Point(p.X, p.Y),
                    top[2]
                };

                Color topColor = ControlPaint.Light(fill, 0.35f);
                Color leftColor = ControlPaint.Dark(fill, 0.15f);
                Color rightColor = fill;

                using (Brush topBrush = new SolidBrush(sceneObject.Kind == "Zone" ? Color.FromArgb(115, topColor) : topColor))
                using (Brush leftBrush = new SolidBrush(sceneObject.Kind == "Zone" ? Color.FromArgb(90, leftColor) : leftColor))
                using (Brush rightBrush = new SolidBrush(sceneObject.Kind == "Zone" ? Color.FromArgb(105, rightColor) : rightColor))
                using (Pen outline = new Pen(sceneObject == selected ? Color.White : Color.FromArgb(12, 14, 18), sceneObject == selected ? 3 : 1))
                {
                    graphics.FillPolygon(leftBrush, left);
                    graphics.FillPolygon(rightBrush, right);
                    graphics.FillPolygon(topBrush, top);
                    graphics.DrawPolygon(outline, left);
                    graphics.DrawPolygon(outline, right);
                    graphics.DrawPolygon(outline, top);
                }
            }

            using (Brush textBrush = new SolidBrush(Color.White))
            {
                graphics.DrawString(sceneObject.Name, Font, textBrush, p.X - w / 2, p.Y - h - d - 20);
            }
        }

        private void DrawOverlay(Graphics graphics)
        {
            string mode = PlayMode ? "PLAY 3D" : "EDIT 3D";
            Color color = PlayMode ? Color.FromArgb(70, 210, 120) : Color.FromArgb(242, 170, 76);

            using (Brush brush = new SolidBrush(color))
            using (Font font = new Font(Font.FontFamily, 12, FontStyle.Bold))
            {
                graphics.DrawString(mode, font, brush, 12, 10);
                graphics.DrawString("EP Forge " + Program.AppVersion, font, Brushes.White, 12, 32);
            }
        }

        private void OnPlayTick(object sender, EventArgs e)
        {
            if (project == null)
            {
                return;
            }

            foreach (SceneObject sceneObject in project.Objects)
            {
                if (sceneObject.Kind == "Actor")
                {
                    sceneObject.X += sceneObject.SpeedX;
                    sceneObject.Y += sceneObject.SpeedY;
                    sceneObject.Z += sceneObject.SpeedZ;

                    if (Math.Abs(sceneObject.X) > 520)
                    {
                        sceneObject.SpeedX = -sceneObject.SpeedX;
                    }

                    if (Math.Abs(sceneObject.Y) > 520)
                    {
                        sceneObject.SpeedY = -sceneObject.SpeedY;
                    }

                    if (sceneObject.Z < 0 || sceneObject.Z > 220)
                    {
                        sceneObject.SpeedZ = -sceneObject.SpeedZ;
                    }
                }
            }

            Invalidate();
        }

        private void RaiseSceneChanged()
        {
            if (SceneChanged != null)
            {
                SceneChanged(this, EventArgs.Empty);
            }
        }
    }

    public class MainForm : Form
    {
        private SceneProject project;
        private string currentPath;
        private readonly ListBox worldList;
        private readonly PropertyGrid inspector;
        private readonly SceneViewport viewport;
        private readonly TextBox log;

        public MainForm()
        {
            Text = "EP Forge " + Program.AppVersion + " - 3D Game Engine";
            Width = 1220;
            Height = 780;
            MinimumSize = new Size(940, 580);
            StartPosition = FormStartPosition.CenterScreen;

            ToolStrip toolbar = BuildToolbar();
            Controls.Add(toolbar);

            SplitContainer mainSplit = new SplitContainer();
            mainSplit.Dock = DockStyle.Fill;
            mainSplit.SplitterDistance = 250;
            mainSplit.Panel1.BackColor = Color.FromArgb(24, 28, 35);
            Controls.Add(mainSplit);
            mainSplit.BringToFront();

            worldList = new ListBox();
            worldList.Dock = DockStyle.Fill;
            worldList.BackColor = Color.FromArgb(24, 28, 35);
            worldList.ForeColor = Color.White;
            worldList.BorderStyle = BorderStyle.None;
            worldList.SelectedIndexChanged += OnWorldSelectionChanged;
            mainSplit.Panel1.Controls.Add(worldList);
            mainSplit.Panel1.Controls.Add(MakePanelHeader("WORLD 3D"));

            SplitContainer editorSplit = new SplitContainer();
            editorSplit.Dock = DockStyle.Fill;
            editorSplit.SplitterDistance = 690;
            mainSplit.Panel2.Controls.Add(editorSplit);

            SplitContainer canvasLogSplit = new SplitContainer();
            canvasLogSplit.Orientation = Orientation.Horizontal;
            canvasLogSplit.Dock = DockStyle.Fill;
            canvasLogSplit.SplitterDistance = 510;
            editorSplit.Panel1.Controls.Add(canvasLogSplit);

            viewport = new SceneViewport();
            viewport.SelectionChanged += OnViewportSelectionChanged;
            viewport.SceneChanged += OnSceneChanged;
            canvasLogSplit.Panel1.Controls.Add(viewport);

            log = new TextBox();
            log.Dock = DockStyle.Fill;
            log.Multiline = true;
            log.ReadOnly = true;
            log.BackColor = Color.FromArgb(18, 21, 27);
            log.ForeColor = Color.FromArgb(205, 214, 226);
            log.BorderStyle = BorderStyle.None;
            canvasLogSplit.Panel2.Controls.Add(log);
            canvasLogSplit.Panel2.Controls.Add(MakePanelHeader("RUN LOG"));

            inspector = new PropertyGrid();
            inspector.Dock = DockStyle.Fill;
            inspector.PropertyValueChanged += OnPropertyChanged;
            editorSplit.Panel2.Controls.Add(inspector);
            editorSplit.Panel2.Controls.Add(MakePanelHeader("PROPERTIES"));

            NewProject();
            CheckUpdates(false);
        }

        private ToolStrip BuildToolbar()
        {
            ToolStrip toolbar = new ToolStrip();
            toolbar.Dock = DockStyle.Top;
            toolbar.GripStyle = ToolStripGripStyle.Hidden;
            toolbar.BackColor = Color.FromArgb(238, 241, 245);

            AddButton(toolbar, "New", "New", OnNewProject);
            AddButton(toolbar, "Open", "Open", OnOpenProject);
            AddButton(toolbar, "Save", "Save", OnSaveProject);
            toolbar.Items.Add(new ToolStripSeparator());
            AddButton(toolbar, "Cube", "+ Cube", OnAddCube);
            AddButton(toolbar, "Zone", "+ Zone", OnAddZone);
            AddButton(toolbar, "Light", "+ Light", OnAddLight);
            toolbar.Items.Add(new ToolStripSeparator());
            AddButton(toolbar, "Play", "Play", OnPlay);
            AddButton(toolbar, "Stop", "Stop", OnStop);
            toolbar.Items.Add(new ToolStripSeparator());
            AddButton(toolbar, "Update", "Check Update", OnCheckUpdate);

            return toolbar;
        }

        private void AddButton(ToolStrip toolbar, string name, string text, EventHandler handler)
        {
            ToolStripButton button = new ToolStripButton(text);
            button.Name = name;
            button.DisplayStyle = ToolStripItemDisplayStyle.Text;
            button.Click += handler;
            toolbar.Items.Add(button);
        }

        private Control MakePanelHeader(string text)
        {
            Label label = new Label();
            label.Text = "  " + text;
            label.Dock = DockStyle.Top;
            label.Height = 28;
            label.TextAlign = ContentAlignment.MiddleLeft;
            label.BackColor = Color.FromArgb(38, 44, 54);
            label.ForeColor = Color.White;
            label.Font = new Font(Font.FontFamily, 8, FontStyle.Bold);
            return label;
        }

        private void NewProject()
        {
            project = new SceneProject();
            project.Objects.Add(MakeObject("Player", "Actor", -160, -80, 30, 72, 72, 72, Color.FromArgb(88, 214, 141), 2, 1, 0));
            project.Objects.Add(MakeObject("Platform", "Zone", 120, 80, 0, 180, 40, 140, Color.FromArgb(88, 166, 255), 0, 0, 0));
            project.Objects.Add(MakeObject("Sun", "Light", 20, -260, 190, 92, 92, 92, Color.FromArgb(242, 170, 76), 0, 0, 0));
            currentPath = null;
            viewport.Project = project;
            RefreshWorld();
            Log("Nowy projekt EP Forge 3D utworzony.");
        }

        private SceneObject MakeObject(string name, string kind, int x, int y, int z, int width, int height, int depth, Color color, int speedX, int speedY, int speedZ)
        {
            SceneObject sceneObject = new SceneObject();
            sceneObject.Name = name;
            sceneObject.Kind = kind;
            sceneObject.X = x;
            sceneObject.Y = y;
            sceneObject.Z = z;
            sceneObject.Width = width;
            sceneObject.Height = height;
            sceneObject.Depth = depth;
            sceneObject.ColorArgb = color.ToArgb();
            sceneObject.SpeedX = speedX;
            sceneObject.SpeedY = speedY;
            sceneObject.SpeedZ = speedZ;
            return sceneObject;
        }

        private void RefreshWorld()
        {
            SceneObject selected = viewport.Selected;
            worldList.Items.Clear();

            foreach (SceneObject sceneObject in project.Objects)
            {
                worldList.Items.Add(sceneObject);
            }

            if (selected != null)
            {
                worldList.SelectedItem = selected;
            }
        }

        private void SelectObject(SceneObject sceneObject)
        {
            viewport.Selected = sceneObject;
            inspector.SelectedObject = sceneObject;
            worldList.SelectedItem = sceneObject;
        }

        private void OnNewProject(object sender, EventArgs e)
        {
            NewProject();
        }

        private void OnOpenProject(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "EP Forge Project (*.epforge)|*.epforge|All files (*.*)|*.*";
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(SceneProject));
                    using (FileStream stream = File.OpenRead(dialog.FileName))
                    {
                        project = (SceneProject)serializer.Deserialize(stream);
                    }

                    currentPath = dialog.FileName;
                    viewport.Project = project;
                    RefreshWorld();
                    Log("Otworzono projekt: " + currentPath);
                }
            }
        }

        private void OnSaveProject(object sender, EventArgs e)
        {
            if (currentPath == null)
            {
                using (SaveFileDialog dialog = new SaveFileDialog())
                {
                    dialog.Filter = "EP Forge Project (*.epforge)|*.epforge|All files (*.*)|*.*";
                    dialog.FileName = "MyGame3D.epforge";
                    if (dialog.ShowDialog(this) != DialogResult.OK)
                    {
                        return;
                    }

                    currentPath = dialog.FileName;
                }
            }

            XmlSerializer serializer = new XmlSerializer(typeof(SceneProject));
            using (FileStream stream = File.Create(currentPath))
            {
                serializer.Serialize(stream, project);
            }

            Log("Zapisano projekt: " + currentPath);
        }

        private void OnAddCube(object sender, EventArgs e)
        {
            AddSceneObject(MakeObject("Cube " + (project.Objects.Count + 1), "Actor", 0, 0, 0, 72, 72, 72, Color.FromArgb(88, 214, 141), 1, 0, 0));
        }

        private void OnAddZone(object sender, EventArgs e)
        {
            AddSceneObject(MakeObject("Zone " + (project.Objects.Count + 1), "Zone", 80, 80, 0, 150, 42, 110, Color.FromArgb(88, 166, 255), 0, 0, 0));
        }

        private void OnAddLight(object sender, EventArgs e)
        {
            AddSceneObject(MakeObject("Light " + (project.Objects.Count + 1), "Light", -80, -160, 180, 90, 90, 90, Color.FromArgb(242, 170, 76), 0, 0, 0));
        }

        private void AddSceneObject(SceneObject sceneObject)
        {
            project.Objects.Add(sceneObject);
            RefreshWorld();
            SelectObject(sceneObject);
            viewport.Invalidate();
            Log("Dodano obiekt 3D: " + sceneObject.Name);
        }

        private void OnPlay(object sender, EventArgs e)
        {
            viewport.StartPlay();
            Log("Play mode 3D wlaczony.");
        }

        private void OnStop(object sender, EventArgs e)
        {
            viewport.StopPlay();
            Log("Play mode zatrzymany.");
        }

        private void OnCheckUpdate(object sender, EventArgs e)
        {
            CheckUpdates(true);
        }

        private void CheckUpdates(bool showUpToDate)
        {
            UpdateInfo update = UpdateChecker.Check();
            if (update == null)
            {
                if (showUpToDate)
                {
                    MessageBox.Show(this, "Masz najnowsza wersje EP Forge: " + Program.AppVersion, "EP Forge Update");
                }
                return;
            }

            DialogResult result = MessageBox.Show(
                this,
                "Dostepna jest nowa wersja EP Forge: " + update.Version + Environment.NewLine + update.Notes + Environment.NewLine + Environment.NewLine + "Zaktualizowac silnik teraz?",
                "Aktualizacja EP Forge",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                if (!File.Exists(update.InstallerPath))
                {
                    MessageBox.Show(this, "Nie znaleziono installera aktualizacji:" + Environment.NewLine + update.InstallerPath, "EP Forge Update");
                    return;
                }

                Process.Start(update.InstallerPath, "/update");
                Close();
            }
        }

        private void OnWorldSelectionChanged(object sender, EventArgs e)
        {
            if (worldList.SelectedItem is SceneObject)
            {
                SelectObject((SceneObject)worldList.SelectedItem);
            }
        }

        private void OnViewportSelectionChanged(object sender, EventArgs e)
        {
            inspector.SelectedObject = viewport.Selected;
            if (viewport.Selected != null && worldList.SelectedItem != viewport.Selected)
            {
                worldList.SelectedItem = viewport.Selected;
            }
        }

        private void OnPropertyChanged(object sender, PropertyValueChangedEventArgs e)
        {
            RefreshWorld();
            viewport.Invalidate();
            Log("Zmieniono: " + e.ChangedItem.Label);
        }

        private void OnSceneChanged(object sender, EventArgs e)
        {
            inspector.Refresh();
        }

        private void Log(string message)
        {
            log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine);
        }
    }
}
