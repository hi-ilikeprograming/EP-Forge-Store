# EP Forge

EP Forge to pierwszy szkic aplikacji **silnik gra** dla Easy Programming.
To jest normalna aplikacja Windows `.exe`, a nie HTML i nie plik `.ep`.

## Co ma w srodku

- `World` - lista obiektow w scenie
- `Canvas` - widok sceny z siatka
- `Properties` - edycja wybranego obiektu
- `Run Log` - dziennik pracy silnika
- `Play` i `Stop` - prosty tryb uruchomienia sceny
- zapis i odczyt projektow `.epforge`

## Budowanie

Kliknij:

```text
build.cmd
```

albo w terminalu:

```powershell
.\build.cmd
```

Wynik:

```text
bin\EPForge.exe
```

## Uruchomienie

Kliknij:

```text
bin\EPForge.exe
```

## Kierunek

To nie jest kopia Unity. Podobne sa tylko podstawowe pomysly, ktore ma prawie kazdy edytor gier: scena, lista obiektow, inspector i play mode.
EP Forge ma byc prostszy, bardziej pod Easy Programming i docelowo polaczony z `import silnik gra`.
